/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignment3;

/**
 *
 * @author uewashuuwa
 */
public class Main {

    public static void main(String[] args) {
        StartScreen startScreen = new StartScreen();
        startScreen.setVisible(true);
    }
}
