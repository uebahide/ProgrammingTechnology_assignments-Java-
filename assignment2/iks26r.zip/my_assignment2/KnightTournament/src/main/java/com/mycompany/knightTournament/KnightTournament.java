/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.knightTournament;

/**
 *
 * @author uewashuuwa
 */
public class KnightTournament {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
